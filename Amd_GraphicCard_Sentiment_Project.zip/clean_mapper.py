#!/opt/homebrew/bin/python3
# -*-coding:utf-8 -*
import sys
import json

def read_input(file):
    for line in file:
        yield line.strip()

def parse_post(post):
    if isinstance(post, dict):
        return process_post(post)
    elif isinstance(post, list):
        results = []
        for item in post:
            result = parse_post(item)
            if result:
                results.append(result)
        return results
    else:
        print(f"Unexpected data format: {post}", file=sys.stderr)
        return None

def process_post(post_data):
    try:
        title = post_data.get('title', '').replace('\n', ' ').replace('\t', ' ')
        selftext = post_data.get('selftext', '').replace('\n', ' ').replace('\t', ' ')
        created_utc = post_data.get('created_utc', 0)
        num_comments = post_data.get('num_comments', 0)
        score = post_data.get('score', 0)
        return f"{title}\t{selftext}\t{created_utc}\t{num_comments}\t{score}"
    except (TypeError, KeyError) as e:
        print(f"Error processing post: {e} - {post_data}", file=sys.stderr)
        return None

if __name__ == "__main__":
    input_data = read_input(sys.stdin)
    for line in input_data:
        try:
            post = json.loads(line)
            parsed_post = parse_post(post)
            if parsed_post:
                if isinstance(parsed_post, list):
                    for p in parsed_post:
                        print(p)
                else:
                    print(parsed_post)
            else:
                print(f"Error parsing post: {line}", file=sys.stderr)
        except json.JSONDecodeError as e:
            print(f"JSONDecodeError: {e} - {line}", file=sys.stderr)
