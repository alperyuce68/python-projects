import praw
import json

# API credentials
client_id = 'BXl1VjYqS06VbxP_2JmCOA'
client_secret = 'Q1jUDUHjjxVRHZ60q275lC6Pg6Io9Q'
user_agent = 'YOUR_USER_AGENT'

# Authentication
reddit = praw.Reddit(client_id=client_id,
                     client_secret=client_secret,
                     user_agent=user_agent)


# Define search parameters
subreddit = 'hardware'  # or any other relevant subreddit
query = 'AMD Graphics Card'
date_since = '2023-01-01'

# Collect posts
posts = []
for submission in reddit.subreddit(subreddit).search(query, sort='new', time_filter='all'):
    post = {
        'title': submission.title,
        'selftext': submission.selftext,
        'created_utc': submission.created_utc,
        'num_comments': submission.num_comments,
        'score': submission.score
    }
    posts.append(post)

# Save data to a JSON file
with open('reddit_posts.json', 'w') as f:
    json.dump(posts, f)f
