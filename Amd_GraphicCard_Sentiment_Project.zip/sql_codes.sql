1-SELECT score, AVG(sentiment) AS avg_sentiment FROM posts GROUP BY score ORDER BY score;

2-SELECT created_utc, AVG(num_comments) AS avg_num_comments
FROM posts
GROUP BY created_utc
ORDER BY created_utc;


3-SELECT score, AVG(num_comments) AS avg_num_comments
FROM posts
GROUP BY score
ORDER BY score;


4-SELECT 
    EXTRACT(YEAR FROM TO_TIMESTAMP(created_utc)) AS year,
    EXTRACT(MONTH FROM TO_TIMESTAMP(created_utc)) AS month,
    AVG(sentiment) AS avg_sentiment
FROM posts
GROUP BY 
    EXTRACT(YEAR FROM TO_TIMESTAMP(created_utc)),
    EXTRACT(MONTH FROM TO_TIMESTAMP(created_utc))
ORDER BY year, month;




5-SELECT 
    EXTRACT(YEAR FROM TO_TIMESTAMP(created_utc)) AS year,
    EXTRACT(MONTH FROM TO_TIMESTAMP(created_utc)) AS month,
    MIN(score) AS min_score,
    MAX(score) AS max_score,
    AVG(score) AS avg_score
FROM reddit_posts_with_sentiment
GROUP BY 
    EXTRACT(YEAR FROM TO_TIMESTAMP(created_utc)),
    EXTRACT(MONTH FROM TO_TIMESTAMP(created_utc))
ORDER BY year, month;



