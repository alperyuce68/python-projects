#!/opt/homebrew/bin/python3

# -*-coding:utf-8 -*
import sys

def read_input(file):
    for line in file:
        yield line.strip()

if __name__ == "__main__":
    input_data = read_input(sys.stdin)
    for post in input_data:
        print(post)
